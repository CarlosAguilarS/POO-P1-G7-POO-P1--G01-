/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Candidatos;

//Importe de los recursos necesarios
import Persona.SuperClasePersona;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author carlo
 */
//Clase candidato hereda atributos de la super clase Persona o clase Padre Persona
public class Candidatos extends SuperClasePersona {

    
    //Variable propia de la clase 
    protected String Partido;
    
    //Constructor de los atributos heredados y propio de la clase
    public Candidatos(String Partido, String nombre, String cedula, int edad) {
        super(nombre, cedula, edad);
        this.Partido = Partido;
    }

    
    
    
    

    
    //Metodo get
    public String getPartido() {
        return Partido;
    }

    //Metodo sett
    public void setPartido(String Partido) {
        this.Partido = Partido;
    }
    
    
    //Metodo mostrar candidadots que tiene almacenado los candidatos
   public void mostrarCandidatos(){
       List<Candidatos>listaCandidatos = new ArrayList<>(); 
       listaCandidatos.add(new Candidatos("Creo","Guillermo Lasso","0919551093",50));
       listaCandidatos.add(new Candidatos("PSC","Cinthya Viteri","0919551093",50));
       listaCandidatos.add(new Candidatos("35xd","Rafael Correa","0919551093",50));
                
       for (Candidatos candidatos: listaCandidatos){
           System.out.println(candidatos.mostrarDatos());
       }
            System.out.println(""); 
    }
   
   //Metodo para presentar datos
public String mostrarDatos(){
        return "\n Partido: "+Partido+ "\n Nombre: "+nombre+ "\n Cedula: "+cedula+ "\n Edad: "+edad;
        
}    
    
}
