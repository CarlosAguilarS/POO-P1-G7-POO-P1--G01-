/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vocales;

//Se importa los recursos necesarios para la implementacion de esta clase
import Persona.SuperClasePersona;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author carlo
 */
//Clase hija Vocal hereda atributos de la clase Padre "SuperClasePersona"
public class Vocal extends SuperClasePersona {
    
    //Atributos de la clase Vocal
    protected String lugarVotacion;
    protected int MesaAsignada;
    protected boolean presidentedeMesa;

    //Constructor de la clase hija Vocal con los atributos propios de la clase y los atributos heredados de la clase Padre Persona
    public Vocal(String lugarVotacion, int MesaAsignada, boolean presidentedeMesa, String nombre, String cedula, int edad) {
        super(nombre, cedula, edad);
        this.lugarVotacion = lugarVotacion;
        this.MesaAsignada = MesaAsignada;
        this.presidentedeMesa = presidentedeMesa;
    }

   
    

    //Metodo get
    public String getLugarVotacion() {
        return lugarVotacion;
    }

    //Metodo Set
    public void setLugarVotacion(String lugarVotacion) {
        this.lugarVotacion = lugarVotacion;
    }

    //Metodo get
    public int getMesaAsignada() {
        return MesaAsignada;
    }

    //Metodo Set
    public void setMesaAsignada(int MesaAsignada) {
        this.MesaAsignada = MesaAsignada;
    }

    //Metodo get
    public boolean getPresidentedeMesa() {
        return presidentedeMesa;
    }

    //Metodo Set
    public void setPresidentedeMesa(boolean presidentedeMesa) {
        this.presidentedeMesa = presidentedeMesa;
    }

    //Metodo Mostrar Vocal, que contiene todos los vocales con todos sus atributos correspondientes
   public void mostrarVocal(){
        List<Vocal>listaVocal = new ArrayList<>();
                
                //Recinto 1:
                //Mesa 1
                listaVocal.add(new Vocal("Sagrados Corazones",1,true,"Jose Juan Perez","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",1,false,"Martha Sapienza","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Sagrados Corazones",2,true,"Angel Aguilar","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",2,false,"Polibio Fernandez", "0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Sagrados Corazones",3,true,"Mateo Garbanzo","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",3,false,"Jose Giraldoe","0919551093",50));
                
                //Recinto 2:
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,true,"Felipe Crespo","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,false,"Mario Vergara","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,true,"Jurggen Jijon","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,false,"Felix Gonzales","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,true,"Carlos Arellanos","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,false,"Brenda Elizalde","0919551093",50));
                
                //Recinto 3:
                listaVocal.add(new Vocal("Universidad Ecotec",1,true,"Harrison Mendoza","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",1,false,"Waleska Campoverderde","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Ecotec",2,true,"Sandra Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",2,false,"Hellen Diaz","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Ecotec",3,true,"Nayeli Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",3,false,"Danilo Eras","0919551093",50));
                
                for (Vocal vocales: listaVocal){
               
                    System.out.println(vocales.mostrarDatos());
                    System.out.println(""); 
                        
                        
                }
    } 
   
   //metodo String para presentar Datos
public String mostrarDatos(){
        return "\n Lugar de Votacion: "+lugarVotacion+ "\n Mesa Asignada: "+MesaAsignada+ "\n Presidente: "+presidentedeMesa+  "\n Nombre: "+nombre+ "\n Cedula: "+cedula+ "\n Edad: "+edad;
        
}     
    
    
}
