/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Delegados;
//Se importa todo los recursos necesarios para el uso de esta clase
import Persona.SuperClasePersona;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author carlo
 */
//Clase hija Delegado que hereda los atributos de la Clase Padre Persona
public class Delegado extends SuperClasePersona {
    
    //Atributos de la clase Delegado
      protected int MesaAsignada;
      protected String lugarVotacion;
      protected String Partido;

      //Constructor de la clase Delegado con los atributos propio de la clase y los atributos heredados de la clase Padre
    public Delegado(int MesaAsignada, String lugarVotacion,String Partido, String nombre, String cedula, int edad) {
        super(nombre, cedula, edad);
        this.Partido=Partido;
        this.MesaAsignada = MesaAsignada;
        this.lugarVotacion = lugarVotacion;
    }

    
    //Metodo get
    public int getMesaAsignada() {
        return MesaAsignada;
    }

    //Metodo set
    public void setMesaAsignada(int MesaAsignada) {
        this.MesaAsignada = MesaAsignada;
    }

    //Metodo get
    public String getLugarVotacion() {
        return lugarVotacion;
    }

    //Metodo set
    public void setLugarVotacion(String lugarVotacion) {
        this.lugarVotacion = lugarVotacion;
    }

    //Metodo get
    public String getPartido() {
        return Partido;
    }

    //Metodo set
    public void setPartido(String Partido) {
        this.Partido = Partido;
    }
    
    //Metodo para mostrar lod delegados que contiene todos los delegados con todos sus atributos correspondientes
   public void mostrarDelegados(){
        List<Delegado>listaDelegado = new ArrayList<>();
        //lugar de votacion 1 (Reciento 1)
        listaDelegado.add(new Delegado(1,"Universidad Espiritu Santo","Creo","Jose Maria","091290121",34));
        listaDelegado.add(new Delegado(2,"Universidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32));
        listaDelegado.add(new Delegado(3,"Universidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36));
        //lugar de votacion 2 (Reciento 2)
        listaDelegado.add(new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34));
        listaDelegado.add(new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32));
        listaDelegado.add(new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36));
        //lugar de votacion 3 (Reciento 3)
        listaDelegado.add(new Delegado(1,"Universidad Ecotec","Creo","Daniel Mendoza","091290121",34));
        listaDelegado.add(new Delegado(2,"Universidad Ecotec","Pachacutik","Nathaly Landines","091290121",32));
        listaDelegado.add(new Delegado(3,"Universidad Ecotec","Lista35","Pamela Bermeo","091290121",36));
        
        for (Delegado delegados: listaDelegado){
           System.out.println(delegados.mostrarDatos());
       }
            System.out.println(""); 
        
    }
   
 
    //metodo String para presentar Datos
    public String mostrarDatos(){
        return "\n Lugar de Votacion: "+lugarVotacion+ "\n Mesa Asignada: "+MesaAsignada+ "\n Partido: "+Partido+ "\n Nombre: "+nombre+ "\n Cedula: "+cedula+ "\n Edad: "+edad;
        
} 
    
    
    
    
}
