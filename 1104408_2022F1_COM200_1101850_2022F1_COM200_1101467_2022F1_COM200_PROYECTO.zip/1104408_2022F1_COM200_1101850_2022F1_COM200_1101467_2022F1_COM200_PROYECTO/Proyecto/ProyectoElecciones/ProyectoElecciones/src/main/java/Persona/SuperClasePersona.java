/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Persona;

/**
 *
 * @author carlo
 */

//Clase Padre o Super Clase Persona
public class SuperClasePersona {
    
    //Atributos de la clase Persona
    protected String nombre;
    protected String cedula;
    protected int edad;

    //Constructor de la clase Persona
    public SuperClasePersona(String nombre, String cedula, int edad) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.edad = edad;
    }
    


    
    
    //Metodo get
    public String getNombre() {
        return nombre;
    }

    //Metodo set
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    //Metodo get
    public String getCedula() {
        return cedula;
    }
    
    //Metodo set
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    //Metodo get
    public int getEdad() {
        return edad;
    }
    
    //Metodo set
    public void setEdad(int edad) {
        this.edad = edad;
    }

    
    
    
}

