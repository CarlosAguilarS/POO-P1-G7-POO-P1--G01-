/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package InicializarSIstema;
import Candidatos.Candidatos;
import Delegados.Delegado;
import Vocales.Vocal;
import Mesa.Mesa;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author carlo
 */
public class InicializarSistema {
   
    //private ArrayList<Candidatos> candidatos;
    
    /*public InicializarSistema(){
        
    }
    
    public ArrayList getCandidatos(){
        candidatos = new ArrayList<Candidatos>();
        candidatos.add(new Candidatos("Creo","Guillermo Lasso","0919551093",50));
        candidatos.add(new Candidatos("PSC","Cinthya Viteri","0919551093",50));
        candidatos.add(new Candidatos("35xd","Rafael Correa","0919551093",50));   
  
    return candidatos;    
    }*/
    
    
    public void DatosInicializar(){
        
        //Inicializar Candidatos forma 1
                /*Candidatos NombresCandidatos[] = new Candidatos[3];
                NombresCandidatos[0] = new Candidatos("Creo","Guillermo Lasso","0919551093",50);
                NombresCandidatos[1] = new Candidatos("PSC","Cinthya Viteri","0919551093",50);
                NombresCandidatos[2] = new Candidatos("35xd","Rafael Correa","0919551093",50);*/
        
        //Inicializar Candidatos forma 2
                List<Candidatos>listaCandidatos = new ArrayList<>();
                    listaCandidatos.add(new Candidatos("Creo","Guillermo Lasso","0919551093",50));
                    listaCandidatos.add(new Candidatos("PSC","Cinthya Viteri","0919551093",50));
                    listaCandidatos.add(new Candidatos("35xd","Rafael Correa","0919551093",50));
        //Inicializar Delegados forma 1
       //Habre 3 lugadres de votacion y 3 mesas
                /*Delegado NombresDelegado[] = new Delegado[9];
                //lugar de votacion 1 (Reciento 1)
                NombresDelegado[0] = new Delegado(1,"Unirsidad Espiritu Santo","Creo","Jose Maria","091290121",34);
                NombresDelegado[1] = new Delegado(2,"Unirsidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32);
                NombresDelegado[2] = new Delegado(3,"Unirsidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36);
                
                //lugar de votacion 2 (Reciento 2)
                NombresDelegado[3] = new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34);
                NombresDelegado[4] = new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32);
                NombresDelegado[5] = new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36);
                
                //lugar de votacion 3 (Reciento 3)
                NombresDelegado[6] = new Delegado(1,"Unirsidad Ecotec","Creo","Daniel Mendoza","091290121",34);
                NombresDelegado[7] = new Delegado(2,"Unirsidad Ecotec","Pachacutik","Nathaly Landines","091290121",32);
                NombresDelegado[8] = new Delegado(3,"Unirsidad Ecotec","Lista35","Pamela Bermeo","091290121",36);*/
        
        //Inicializar Delegados forma 2
                List<Delegado>listaDelegado = new ArrayList<>();
                        //lugar de votacion 1 (Reciento 1)
                        listaDelegado.add(new Delegado(1,"Universidad Espiritu Santo","Creo","Jose Maria","091290121",34));
                        listaDelegado.add(new Delegado(2,"Universidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32));
                        listaDelegado.add(new Delegado(3,"Universidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36));
                         //lugar de votacion 2 (Reciento 2)
                        listaDelegado.add(new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34));
                        listaDelegado.add(new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32));
                        listaDelegado.add(new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36));
                        //lugar de votacion 3 (Reciento 3)
                        listaDelegado.add(new Delegado(1,"Universidad Ecotec","Creo","Daniel Mendoza","091290121",34));
                        listaDelegado.add(new Delegado(2,"Universidad Ecotec","Pachacutik","Nathaly Landines","091290121",32));
                        listaDelegado.add(new Delegado(3,"Universidad Ecotec","Lista35","Pamela Bermeo","091290121",36));
                
        //Inicializar Vocales forma 1
        /*Vocal NombresVocales[] = new Vocal[18];
                
                
                //Mesa 1, reciento 1
                NombresVocales[0] = new Vocal("Sagrados Corazones",1,true,"Jose Juan Perez","0919551093",50);
                NombresVocales[1] = new Vocal("Sagrados Corazones",1,false,"Martha Sapienza","0919551093",50);
                
                
                //Mesa 2, reciento 1
                NombresVocales[2] = new Vocal("Sagrados Corazones",2,true,"Angel Aguilar","0919551093",50);
                NombresVocales[3] = new Vocal("Sagrados Corazones",2,false,"Polibio Fernandez", "0919551093",50);
                
                //Mesa 3, reciento 1
                NombresVocales[4] = new Vocal("Sagrados Corazones",3,true,"Mateo Garbanzo","0919551093",50);
                NombresVocales[5] = new Vocal("Sagrados Corazones",3,false,"Jose Giraldoe","0919551093",50);
               
                 //Mesa 1, reciento 2
                NombresVocales[6] = new Vocal("Unirsidad Espiritu Santo",1,true,"Felipe Crespo","0919551093",50);
                NombresVocales[7] = new Vocal("Unirsidad Espiritu Santo",1,false,"Mario Vergara","0919551093",50);
                
                
                //Mesa 2, reciento 2
                NombresVocales[8] = new Vocal("Unirsidad Espiritu Santo",2,true,"Jurggen Jijon","0919551093",50);
                NombresVocales[9] = new Vocal("Unirsidad Espiritu Santo",2,false,"Felix Gonzales","0919551093",50);
                
                //Mesa 3, reciento 2
                NombresVocales[10] = new Vocal("Unirsidad Espiritu Santo",3,true,"Carlos Arellanos","0919551093",50);
                NombresVocales[11] = new Vocal("Unirsidad Espiritu Santo",3,false,"Brenda Elizalde","0919551093",50);
                
                  //Mesa 1, reciento 3
                NombresVocales[12] = new Vocal("Unirsidad Ecotec",1,true,"Harrison Mendoza","0919551093",50);
                NombresVocales[13] = new Vocal("Unirsidad Ecotec",1,false,"Waleska Campoverderde","0919551093",50);
                
                
                //Mesa 2, reciento 3
                NombresVocales[14] = new Vocal("Unirsidad Ecotec",2,true,"Sandi Romero","0919551093",50);
                NombresVocales[15] = new Vocal("Unirsidad Ecotec",2,false,"Hellen Diaz","0919551093",50);
                
                //Mesa 3, reciento 3
                NombresVocales[16] = new Vocal("Unirsidad Ecotec",3,true,"Nayeli Romero","0919551093",50);
                NombresVocales[17] = new Vocal("Unirsidad Ecotec",3,false,"Danilo Eras","0919551093",50);*/
                
        //Inicializar vocal forma 2
                List<Vocal>listaVocal = new ArrayList<>();
                
                //Recinto 1:
                //Mesa 1
                listaVocal.add(new Vocal("Sagrados Corazones",1,true,"Jose Juan Perez","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",1,false,"Martha Sapienza","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Sagrados Corazones",2,true,"Angel Aguilar","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",2,false,"Polibio Fernandez", "0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Sagrados Corazones",3,true,"Mateo Garbanzo","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",3,false,"Jose Giraldoe","0919551093",50));
                
                //Recinto 2:
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,true,"Felipe Crespo","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,false,"Mario Vergara","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,true,"Jurggen Jijon","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,false,"Felix Gonzales","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,true,"Carlos Arellanos","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,false,"Brenda Elizalde","0919551093",50));
                
                //Recinto 3:
                listaVocal.add(new Vocal("Universidad Ecotec",1,true,"Harrison Mendoza","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",1,false,"Waleska Campoverderde","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Ecotec",2,true,"Sandra Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",2,false,"Hellen Diaz","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Ecotec",3,true,"Nayeli Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",3,false,"Danilo Eras","0919551093",50));
                
                //Mesa y votos xd
                List<Mesa>listaMesa = new ArrayList<>();
                
                //Recinto 1:
                listaMesa.add(new Mesa("Sagrados Corazones",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Sagrados Corazones",2,"Mujer",600,592,425,122,45)); //Mesa 2
                listaMesa.add(new Mesa("Sagrados Corazones",2,"Hombre",600,500,300,150,50)); //Mesa 3
                
                //Recinto 2:
                listaMesa.add(new Mesa("Universidad Espiritu Santo",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Universidad Espiritu Santo",2,"Mujer",600,592,425,122,45)); //Mesa 2
                listaMesa.add(new Mesa("Universidad Espiritu Santo",2,"Hombre",600,500,300,150,50)); //Mesa 3
                
                //Recinto 3:
                listaMesa.add(new Mesa("Universidad Ecotec",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Universidad Ecotec",2,"Mujer",600,592,425,122,45)); //Mesa 2
                listaMesa.add(new Mesa("Universidad Ecotec",2,"Hombre",600,500,300,150,50)); //Mesa 3
        
    }
    
}
