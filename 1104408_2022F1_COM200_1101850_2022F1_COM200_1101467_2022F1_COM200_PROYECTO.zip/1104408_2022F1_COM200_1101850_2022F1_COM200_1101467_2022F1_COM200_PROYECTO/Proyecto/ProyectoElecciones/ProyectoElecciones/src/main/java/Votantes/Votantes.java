/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Votantes;

import Persona.SuperClasePersona;

/**
 *
 * @author carlo
 */
public class Votantes extends SuperClasePersona {
   
    protected String lugarVotacion;
    protected int MesaAsignada;
    protected String sexo;

    public Votantes(String lugarVotacion, int MesaAsignada, String sexo, String nombre, String cedula, int edad) {
        super(nombre, cedula, edad);
        this.lugarVotacion = lugarVotacion;
        this.MesaAsignada = MesaAsignada;
        this.sexo = sexo;
    }

    public String getLugarVotacion() {
        return lugarVotacion;
    }

    public void setLugarVotacion(String lugarVotacion) {
        this.lugarVotacion = lugarVotacion;
    }

    public int getMesaAsignada() {
        return MesaAsignada;
    }

    public void setMesaAsignada(int MesaAsignada) {
        this.MesaAsignada = MesaAsignada;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    public String mostrarDatos(){
        return "\n Nombre: "+nombre+ "\n Cedula: "+cedula+ "\n Edad: "+edad+ "\n Lugar de votacion: "+lugarVotacion+ "\n Sexo: "+sexo+ "\n Mesa Asignada: "+MesaAsignada;
    }
    
}
