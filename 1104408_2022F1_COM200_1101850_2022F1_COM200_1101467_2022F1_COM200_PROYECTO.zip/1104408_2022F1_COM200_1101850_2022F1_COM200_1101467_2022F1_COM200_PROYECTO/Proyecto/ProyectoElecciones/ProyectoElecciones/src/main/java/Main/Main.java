/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
//Importe de los recursos necesarios
import Candidatos.Candidatos;
import Delegados.Delegado;
import Vocales.Vocal;
import Mesa.Mesa;
import java.util.Scanner;
import java .util.*;

//private InicializarSistema empresa = new InicializarSIstema();
/**
 *
 * @author carlo
 */

 
public class Main {
    
    //Inicializacion de Arreglos
    List<Delegado>listaDelegado = new ArrayList<>();
    List<Vocal>listaVocal = new ArrayList<>();
    List<Mesa>listaMesa = new ArrayList<>();
    datosIniciales elegirOpcion = new datosIniciales();
    
    
    //Inicio del menu
    public void MenuUsario(){
        
        //Variables del menu
        boolean opcionIngresada=false;
        boolean opcionIngresada2=false;
        int eleccionUsuario;
        Scanner entradaDatos = new Scanner(System.in);
        
        do{
        //Menu
        System.out.println("¡Bienvenido al Menú!\n");
        System.out.println("A continuación, eliga la opción a realizar:");
        System.out.println("Opción 1 > Consultar Candidatos");
        System.out.println("Opción 2 > Consultar Delegados del Partido");//Habra 3 delegados de partido por reciento, uno en cada mesa
        System.out.println("Opción 3 > Consultar Vocales del Partido");//Habre 2 vocales uno de ellos sera presidente
        System.out.println("Opción 4 > Consultar Lugar Votacion"); //habra 3 lugares de votacion y 3 mesas nomas
        System.out.println("Opción 5 > Votar Usuario");
        System.out.println("Opción 6 > Salir");
        System.out.print("Ingrese su Opción: " );
        eleccionUsuario = entradaDatos.nextInt();
        while(eleccionUsuario < 1 || eleccionUsuario > 6){
            System.out.print("Opción incorrecta. Ingrese una opción perteneciente al Menú: "); //Validacion de menu
            eleccionUsuario = entradaDatos.nextInt();
        }
        //Inicializacioness
        Candidatos objCandidatos = new Candidatos("", "", "", 0);
        Delegado objDelegados = new Delegado(0, "", "", "", "", 0);
        Vocal objVocal = new Vocal("", 0, false, "", "", 0);
        
        
                
        //Inicio de los casos del menu
            switch(eleccionUsuario){
            case 1 -> {
                objCandidatos.mostrarCandidatos();
               
                
            }
            
            case 2 -> {
                objDelegados.mostrarDelegados();
                
                
                
            }
            
            
            case 3 -> {
                objVocal.mostrarVocal();
               
                
            }
        
        
            case 4 -> {
                
                 elegirOpcion.elegirOpcion(opcionIngresada);
                opcionIngresada=true;
                
                
            }
       
               
            case 5 -> {
                
                
                elegirOpcion.votacionUsuario(opcionIngresada,opcionIngresada2);
                opcionIngresada=true;
                opcionIngresada2=true;
                
            }
            
            case 6 -> {
                
                 System.out.println("Gracias por usar el menu");
                
                
            }

                
            }
            
        }while(eleccionUsuario != 6);
        
        
            
            
        }
    
        
    
    
    
       
    }
    

