/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mesa;

import Vocales.Vocal;

/**
 *
 * @author carlo
 */
public class Mesa  {
    
    protected String lugarVotacion;
    protected int MesaAsignada;
    protected String sexoMesa;
    protected int numeroVotantes;
    //protected int numeroVocales;
    //protected int numeroPresidente;
    protected double votosTotales;
    protected double votosPartido1;
    protected double votosPartido2;
    protected double votosPartido3;

    //Constructor de la clase mesa con los atributos propios de la clase
    public Mesa(String lugarVotacion, int MesaAsignada, String sexoMesa, int numeroVotantes, double votosTotales, double votosPartido1, double votosPartido2, double votosPartido3) {
        this.lugarVotacion = lugarVotacion;
        this.MesaAsignada = MesaAsignada;
        this.sexoMesa = sexoMesa;
        this.numeroVotantes = numeroVotantes;
        this.votosTotales = votosTotales;
        this.votosPartido1 = votosPartido1;
        this.votosPartido2 = votosPartido2;
        this.votosPartido3 = votosPartido3;
    }

    
    //Se declaran todos los metodos setters y getters
    
    public String getLugarVotacion() {
        return lugarVotacion;
    }

    public void setLugarVotacion(String lugarVotacion) {
        this.lugarVotacion = lugarVotacion;
    }

    public int getMesaAsignada() {
        return MesaAsignada;
    }

    public void setMesaAsignada(int MesaAsignada) {
        this.MesaAsignada = MesaAsignada;
    }

    public String getSexoMesa() {
        return sexoMesa;
    }

    public void setSexoMesa(String sexoMesa) {
        this.sexoMesa = sexoMesa;
    }

    public int getNumeroVotantes() {
        return numeroVotantes;
    }

    public void setNumeroVotantes(int numeroVotantes) {
        this.numeroVotantes = numeroVotantes;
    }

    public double getVotosTotales() {
        return votosTotales;
    }

    public void setVotosTotales(double votosTotales) {
        this.votosTotales = votosTotales;
    }

    public double getVotosPartido1() {
        return votosPartido1;
    }

    public void setVotosPartido1(double votosPartido1) {
        this.votosPartido1 = votosPartido1;
    }

    public double getVotosPartido2() {
        return votosPartido2;
    }

    public void setVotosPartido2(double votosPartido2) {
        this.votosPartido2 = votosPartido2;
    }

    public double getVotosPartido3() {
        return votosPartido3;
    }

    public void setVotosPartido3(double votosPartido3) {
        this.votosPartido3 = votosPartido3;
    }

   
public String mostrarDatos(){
        return "\n Lugar de Votacion: "+lugarVotacion+ "\n Mesa Asignada: "+MesaAsignada+ "\n Sexo de mesa: "+sexoMesa+  "\n Nuemros Votantes: "+numeroVotantes+ "\n Numero de votos totales: "+votosTotales+ "\n Votos de partido 1: "+votosPartido1 + "\n Votos de partido 2: "+votosPartido2 + "\n Votos de partido 3: "+votosPartido3;
        
} 
    
    
}
