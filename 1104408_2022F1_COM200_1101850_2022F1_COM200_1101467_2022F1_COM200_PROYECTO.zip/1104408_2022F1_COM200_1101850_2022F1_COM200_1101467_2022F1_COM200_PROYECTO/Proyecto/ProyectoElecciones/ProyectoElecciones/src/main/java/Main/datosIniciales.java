/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
//Se importan las librerias y recursos necesarios para poder implementar la clase correctamente
import Delegados.Delegado;
import Mesa.Mesa;
import Persona.SuperClasePersona;
import Vocales.Vocal;
import Votantes.Votantes;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author carlo
 */
public class datosIniciales {
    
    //Aqui se inicializan los arrayslist
    double votacion1=0;
    double votacion2=0;
    double votacion3=0;
    double Sumavotacion1=0;
    double Sumavotacion2=0;
    double Sumavotacion3=0;
    int validacion = 0, voto = 0, Vmesa;
    String lugar = new String();
    List<Votantes>listaVotantes = new ArrayList<>();
    List<Delegado>listaDelegado = new ArrayList<>();
    List<Vocal>listaVocal = new ArrayList<>();
    List<Mesa>listaMesa = new ArrayList<>();
    
    
    
    //Metodo elegir opcion, la opcion 4 para mostrar filtrado los datos
    public void elegirOpcion(boolean opcionIngresada){
        Scanner entradaDatos = new Scanner(System.in);
       int opc, validacion1=0;
                
                
               if(opcionIngresada==false){
                    listaDelegadosMesa(); 
                   
               }
                   
                
                  
                    
                
                System.out.println("Escoja el lugar de votacion que desea consultar");
                System.out.println("Reciento 1: Universidad Espiritu Santo ");
                System.out.println("Reciento 2: Sagrados Corazones ");
                System.out.println("Reciento 3: Universidad Ecotec");
                 opc = entradaDatos.nextInt();
                while(opc < 1 || opc > 3){
                System.out.print("Opción incorrecta. Ingrese una opción perteneciente al Menú: ");
                opc = entradaDatos.nextInt();
                }
                
                switch(opc){
                    
                    case 1:{ 
                       String a = new String ("Universidad Espiritu Santo");
                        
                       
                        System.out.println("\n** Universidad Espiritu Santo**");
                        //Presenta Delegados del recinto 
                        System.out.println("\n** Delegados **");
                        for (Delegado delegados: listaDelegado){
               
                        if (delegados.getLugarVotacion().equalsIgnoreCase(a)){
                           System.out.println(delegados.mostrarDatos());
                            System.out.println(""); 
                        }}
                        
                        //Presenta Vocales del recinto 
                        System.out.println("\n** Vocales **");
                        for (Vocal vocales: listaVocal){
               
                        if (vocales.getLugarVotacion().equalsIgnoreCase(a)){
                           System.out.println(vocales.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Mesas y votos del recinto 
                        System.out.println("\n** Mesas y respectivos votos **");
                        for (Mesa mesas: listaMesa){
               
                        if (mesas.getLugarVotacion().equalsIgnoreCase(a)){
                           System.out.println(mesas.mostrarDatos());
                           System.out.println("El porcentaje de votos del partido 1 es: " +( mesas.getVotosPartido1()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 2 es: " +( mesas.getVotosPartido2()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 3 es: " +( mesas.getVotosPartido3()/mesas.getVotosTotales() )*100 );
                            System.out.println(""); 
                        }}
                        
                        }
                        
                        
                    break;
                    
                    case 2:{ 
                       String b = new String ("Sagrados Corazones");
                        
                       
                        System.out.println("\n** Sagrados Corazones**");
                        //Presenta Delegados del recinto 
                        System.out.println("\n** Delegados **");
                        for (Delegado delegados: listaDelegado){
               
                        if (delegados.getLugarVotacion().equalsIgnoreCase(b)){
                           System.out.println(delegados.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Vocales del recinto
                        System.out.println("\n** Vocales **");
                        for (Vocal vocales: listaVocal){
               
                        if (vocales.getLugarVotacion().equalsIgnoreCase(b)){
                           System.out.println(vocales.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Mesas y votos del recinto 
                        System.out.println("\n** Mesas y respectivos votos **");
                        for (Mesa mesas: listaMesa){
               
                        if (mesas.getLugarVotacion().equalsIgnoreCase(b)){
                           System.out.println(mesas.mostrarDatos());
                           System.out.println("El porcentaje de votos del partido 1 es: " +( mesas.getVotosPartido1()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 2 es: " +( mesas.getVotosPartido2()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 3 es: " +( mesas.getVotosPartido3()/mesas.getVotosTotales() )*100 );
                            System.out.println(""); 
                        }}
                        
                        }
                    break;
                    
                    case 3:{ 
                       String c = new String ("Universidad Ecotec");
                        
                       
                        System.out.println("\n** Universidad Ecotec**");
                        //Presenta Delegados del recinto 
                        System.out.println("\n** Delegados **");
                        for (Delegado delegados: listaDelegado){
               
                        if (delegados.getLugarVotacion().equalsIgnoreCase(c)){
                           System.out.println(delegados.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Vocales del recinto 
                        System.out.println("\n** Vocales **");
                        for (Vocal vocales: listaVocal){
               
                        if (vocales.getLugarVotacion().equalsIgnoreCase(c)){
                           System.out.println(vocales.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Mesas y votos del recinto 
                        System.out.println("\n** Mesas y respectivos votos **");
                        for (Mesa mesas: listaMesa){
               
                        if (mesas.getLugarVotacion().equalsIgnoreCase(c)){
                           System.out.println(mesas.mostrarDatos());
                           System.out.println("El porcentaje de votos del partido 1 es: " +( mesas.getVotosPartido1()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 2 es: " +( mesas.getVotosPartido2()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 3 es: " +( mesas.getVotosPartido3()/mesas.getVotosTotales() )*100 );
                            System.out.println(""); 
                        }}
                        
                        }
                    break;
                    
                    
                    }
                    
                 
                
               
   }
    
    
    public void votacionUsuario(boolean opcionIngresada, boolean opcionIngresada2){
        int nEdad;
        String ced,nNombre,nSexo;
        Scanner entradaDatos = new Scanner(System.in);
                
                if(opcionIngresada==false){
                    listaDelegadosMesa(); 
                   
                }
                
                if(opcionIngresada2==false){
                    cedulasVotantes();
                   
                }
                  
                
                
                
                 System.out.println("Ingrese su numero de cedula");
                 ced = entradaDatos.nextLine();
                 entradaDatos.nextLine();
                 
                
                
                 for (Votantes votantes: listaVotantes){
               
                        if (votantes.getCedula().equalsIgnoreCase(ced)){
                           System.out.println(votantes.mostrarDatos());
                            System.out.println("");
                            validacion = 1;
                            lugar = (votantes.getLugarVotacion() );
                            Vmesa = ( votantes.getMesaAsignada() );
                        }}  
              
                 
                 if(validacion == 0){
                 System.out.println("Su cedula no se encuentra registrada, procederemos a registrarlo");
                 System.out.println("Ingrese su nombre");
                 nNombre = entradaDatos.nextLine();
                 System.out.println("Ingrese su sexo");
                 nSexo = entradaDatos.nextLine();
                 System.out.println("Ingrese su edad");
                 nEdad = entradaDatos.nextInt();
                 listaVotantes.add(new Votantes("Universidad Espiritu Santo",1,nSexo,nNombre,ced,nEdad));
                 System.out.println("Se le asigno: \nEl reciento: Universidad Espiritu Santo \nMesa :1 "); 
                 
                 for (Votantes votantes: listaVotantes){
               
                        if (votantes.getCedula().equalsIgnoreCase(ced)){
                           System.out.println(votantes.mostrarDatos());
                            System.out.println("");
                            
                            lugar = ( votantes.getLugarVotacion() );
                            Vmesa = ( votantes.getMesaAsignada() );
                        }}  
                 }
                 
                 
                System.out.println("Elija cual partido desea votar: ");
                System.out.println("Partido 1: Creo ");
                System.out.println("Partido 2: PSC");
                System.out.println("Partido 3: Lista 35");
                 voto = entradaDatos.nextInt();
                 while(voto < 1 || voto > 3){
                System.out.print("Opción incorrecta. Ingrese una opción perteneciente al Menú: "); //Validacion de menu
                voto = entradaDatos.nextInt();
                }
                 
                 if(voto==1){
                     
                   System.out.println("Usted voto por el partido 1");
                   //votacion1=1;  
                   
                        for (Mesa mesas: listaMesa){
                            
                        if ((mesas.getMesaAsignada() == Vmesa ) && (mesas.getLugarVotacion().equalsIgnoreCase(lugar))  ){
                            
                            mesas.setVotosPartido1( (mesas.getVotosPartido1() + 1) );
                            mesas.setVotosTotales( (mesas.getVotosTotales() + 1) );
                        }}
                   
                 }if(voto==2){
        
                  System.out.println("Usted voto por el partido 2");
                   //votacion1=1;  
                   
                        for (Mesa mesas: listaMesa){
               
                        if ((mesas.getMesaAsignada() == Vmesa) && (mesas.getLugarVotacion().equalsIgnoreCase(lugar))  ){
                            
                            mesas.setVotosPartido2( (mesas.getVotosPartido2() + 1) );
                            mesas.setVotosTotales( (mesas.getVotosTotales() + 1) );
                        }}
                        
                 }if(voto==3){
                     
                  System.out.println("Usted voto por el partido 3");
                   //votacion1=1;  
                   
                        for (Mesa mesas: listaMesa){
               
                        if ((mesas.getMesaAsignada() == Vmesa) && (mesas.getLugarVotacion().equalsIgnoreCase(lugar))  ){

                            mesas.setVotosPartido3( (mesas.getVotosPartido3() + 1) );
                            mesas.setVotosTotales( (mesas.getVotosTotales() + 1) );
                        }}
                 }
                /*System.out.println("Escoja el lugar de votacion que desea votar");
                System.out.println("Reciento 1: Universidad Espiritu Santo ");
                System.out.println("Reciento 2: Sagrados Corazones ");
                System.out.println("Reciento 3: Universidad Ecotec");
                 opc = entradaDatos.nextInt();
                while(opc < 1 || opc > 3){
                System.out.print("Opción incorrecta. Ingrese una opción perteneciente al Menú: ");
                opc = entradaDatos.nextInt();
                }
                
                switch(opc){
                
        
        
        
                }*/
        
    }
   
    
    public void cedulasVotantes(){
        
        listaVotantes.add(new Votantes("Universidad Espiritu Santo",1,"Hombre","Carlos Aguilar","0927927616",20));
        listaVotantes.add(new Votantes("Universidad Espiritu Santo",2,"Mujer","Mily Aguilar","0927927615",19));
        listaVotantes.add(new Votantes("Universidad Espiritu Santo",3,"Hombre","Luka Suarez","0927927614",18));
        
        listaVotantes.add(new Votantes("Sagrados Corazones",1,"Hombre","Gabriel Aguilar","0927927613",20));
        listaVotantes.add(new Votantes("Sagrados Corazones",2,"Mujer","Mimi Aguilar","0927927612",19));
        listaVotantes.add(new Votantes("Sagrados Corazones",3,"Hombre","Martin Suarez","0927927611",18));
        
        listaVotantes.add(new Votantes("Universidad Ecotec",1,"Hombre","Pedro Aguilar","0927927610",20));
        listaVotantes.add(new Votantes("Universidad Ecotec",2,"Mujer","Mary Aguilar","0927927609",19));
        listaVotantes.add(new Votantes("Universidad Ecotec",3,"Hombre","Rammus Suarez","0927927608",18));
    }
    //Inicializacion de arrayslist
   public void listaDelegadosMesa(){
      
        //lugar de votacion 1 (Reciento 1)
        listaDelegado.add(new Delegado(1,"Universidad Espiritu Santo","Creo","Jose Maria","091290121",34));
        listaDelegado.add(new Delegado(2,"Universidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32));
        listaDelegado.add(new Delegado(3,"Universidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36));
        //lugar de votacion 2 (Reciento 2)
        listaDelegado.add(new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34));
        listaDelegado.add(new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32));
        listaDelegado.add(new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36));
        //lugar de votacion 3 (Reciento 3)
        listaDelegado.add(new Delegado(1,"Universidad Ecotec","Creo","Daniel Mendoza","091290121",34));
        listaDelegado.add(new Delegado(2,"Universidad Ecotec","Pachacutik","Nathaly Landines","091290121",32));
        listaDelegado.add(new Delegado(3,"Universidad Ecotec","Lista35","Pamela Bermeo","091290121",36));
        
        //Recinto 1:
                //Mesa 1
                listaVocal.add(new Vocal("Sagrados Corazones",1,true,"Jose Juan Perez","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",1,false,"Martha Sapienza","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Sagrados Corazones",2,true,"Angel Aguilar","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",2,false,"Polibio Fernandez", "0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Sagrados Corazones",3,true,"Mateo Garbanzo","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",3,false,"Jose Giraldoe","0919551093",50));
                
                //Recinto 2:
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,true,"Felipe Crespo","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,false,"Mario Vergara","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,true,"Jurggen Jijon","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,false,"Felix Gonzales","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,true,"Carlos Arellanos","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,false,"Brenda Elizalde","0919551093",50));
                
                //Recinto 3:
                listaVocal.add(new Vocal("Universidad Ecotec",1,true,"Harrison Mendoza","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",1,false,"Waleska Campoverderde","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Ecotec",2,true,"Sandra Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",2,false,"Hellen Diaz","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Ecotec",3,true,"Nayeli Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",3,false,"Danilo Eras","0919551093",50));
        
                //Mesas votos
                //Recinto 1:
                listaMesa.add(new Mesa("Sagrados Corazones",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Sagrados Corazones",2,"Mujer",600,592,425,122,45)); //Mesa 2
                listaMesa.add(new Mesa("Sagrados Corazones",3,"Hombre",600,500,300,150,50)); //Mesa 3
                
                //Recinto 2:
                listaMesa.add(new Mesa("Universidad Espiritu Santo",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Universidad Espiritu Santo",2,"Mujer",600,582,420,122,44)); //Mesa 2
                listaMesa.add(new Mesa("Universidad Espiritu Santo",3,"Hombre",600,520,305,165,50)); //Mesa 3
                
                //Recinto 3:
                listaMesa.add(new Mesa("Universidad Ecotec",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Universidad Ecotec",2,"Mujer",600,562,415,112,35)); //Mesa 2
                listaMesa.add(new Mesa("Universidad Ecotec",3,"Hombre",600,550,320,170,60)); //Mesa 3      
        
   }
    
    
}
