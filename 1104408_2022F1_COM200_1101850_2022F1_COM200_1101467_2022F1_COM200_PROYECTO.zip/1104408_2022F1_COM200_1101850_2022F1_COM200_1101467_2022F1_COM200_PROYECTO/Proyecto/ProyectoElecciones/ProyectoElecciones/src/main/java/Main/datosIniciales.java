/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
//Se importan las librerias y recursos necesarios para poder implementar la clase correctamente
import Delegados.Delegado;
import Mesa.Mesa;
import Persona.SuperClasePersona;
import Vocales.Vocal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author carlo
 */
public class datosIniciales {
    
    //Aqui se inicializan los arrayslist
    List<Delegado>listaDelegado = new ArrayList<>();
    List<Vocal>listaVocal = new ArrayList<>();
    List<Mesa>listaMesa = new ArrayList<>();
    Scanner entradaDatos = new Scanner(System.in);
    
    //Metodo elegir opcion, la opcion 4 para mostrar filtrado los datos
    public void elegirOpcion(){
       int opc;
                
                listaDelegadosMesa();
                System.out.println("Escoja el lugar de votacion que desea consultar");
                System.out.println("Reciento 1: Universidad Espiritu Santo ");
                System.out.println("Reciento 2: Sagrados Corazones ");
                System.out.println("Reciento 3: Universidad Ecotec");
                 opc = entradaDatos.nextInt();
                while(opc < 1 || opc > 3){
                System.out.print("Opción incorrecta. Ingrese una opción perteneciente al Menú: ");
                opc = entradaDatos.nextInt();
                }
                
                switch(opc){
                    
                    case 1:{ 
                       String a = new String ("Universidad Espiritu Santo");
                        
                       
                        System.out.println("\n** Universidad Espiritu Santo**");
                        //Presenta Delegados del recinto 
                        System.out.println("\n** Delegados **");
                        for (Delegado delegados: listaDelegado){
               
                        if (delegados.getLugarVotacion().equalsIgnoreCase(a)){
                           System.out.println(delegados.mostrarDatos());
                            System.out.println(""); 
                        }}
                        
                        //Presenta Vocales del recinto 
                        System.out.println("\n** Vocales **");
                        for (Vocal vocales: listaVocal){
               
                        if (vocales.getLugarVotacion().equalsIgnoreCase(a)){
                           System.out.println(vocales.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Mesas y votos del recinto 
                        System.out.println("\n** Mesas y respectivos votos **");
                        for (Mesa mesas: listaMesa){
               
                        if (mesas.getLugarVotacion().equalsIgnoreCase(a)){
                           System.out.println(mesas.mostrarDatos());
                           System.out.println("El porcentaje de votos del partido 1 es: " +( mesas.getVotosPartido1()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 2 es: " +( mesas.getVotosPartido2()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 3 es: " +( mesas.getVotosPartido3()/mesas.getVotosTotales() )*100 );
                            System.out.println(""); 
                        }}
                        
                        }
                        
                        
                    break;
                    
                    case 2:{ 
                       String b = new String ("Sagrados Corazones");
                        
                       
                        System.out.println("\n** Sagrados Corazones**");
                        //Presenta Delegados del recinto 
                        System.out.println("\n** Delegados **");
                        for (Delegado delegados: listaDelegado){
               
                        if (delegados.getLugarVotacion().equalsIgnoreCase(b)){
                           System.out.println(delegados.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Vocales del recinto
                        System.out.println("\n** Vocales **");
                        for (Vocal vocales: listaVocal){
               
                        if (vocales.getLugarVotacion().equalsIgnoreCase(b)){
                           System.out.println(vocales.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Mesas y votos del recinto 
                        System.out.println("\n** Mesas y respectivos votos **");
                        for (Mesa mesas: listaMesa){
               
                        if (mesas.getLugarVotacion().equalsIgnoreCase(b)){
                           System.out.println(mesas.mostrarDatos());
                           System.out.println("El porcentaje de votos del partido 1 es: " +( mesas.getVotosPartido1()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 2 es: " +( mesas.getVotosPartido2()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 3 es: " +( mesas.getVotosPartido3()/mesas.getVotosTotales() )*100 );
                            System.out.println(""); 
                        }}
                        
                        }
                    break;
                    
                    case 3:{ 
                       String c = new String ("Universidad Ecotec");
                        
                       
                        System.out.println("\n** Universidad Ecotec**");
                        //Presenta Delegados del recinto 
                        System.out.println("\n** Delegados **");
                        for (Delegado delegados: listaDelegado){
               
                        if (delegados.getLugarVotacion().equalsIgnoreCase(c)){
                           System.out.println(delegados.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Vocales del recinto 
                        System.out.println("\n** Vocales **");
                        for (Vocal vocales: listaVocal){
               
                        if (vocales.getLugarVotacion().equalsIgnoreCase(c)){
                           System.out.println(vocales.mostrarDatos());
                            System.out.println(""); 
                        }}
                        //Presenta Mesas y votos del recinto 
                        System.out.println("\n** Mesas y respectivos votos **");
                        for (Mesa mesas: listaMesa){
               
                        if (mesas.getLugarVotacion().equalsIgnoreCase(c)){
                           System.out.println(mesas.mostrarDatos());
                           System.out.println("El porcentaje de votos del partido 1 es: " +( mesas.getVotosPartido1()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 2 es: " +( mesas.getVotosPartido2()/mesas.getVotosTotales() )*100 );
                           System.out.println("El porcentaje de votos del partido 3 es: " +( mesas.getVotosPartido3()/mesas.getVotosTotales() )*100 );
                            System.out.println(""); 
                        }}
                        
                        }
                    break;
                    
                    
                    }
                    
                 
                
               
   }
   
    //Inicializacion de arrayslist
   public void listaDelegadosMesa(){
      
        //lugar de votacion 1 (Reciento 1)
        listaDelegado.add(new Delegado(1,"Universidad Espiritu Santo","Creo","Jose Maria","091290121",34));
        listaDelegado.add(new Delegado(2,"Universidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32));
        listaDelegado.add(new Delegado(3,"Universidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36));
        //lugar de votacion 2 (Reciento 2)
        listaDelegado.add(new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34));
        listaDelegado.add(new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32));
        listaDelegado.add(new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36));
        //lugar de votacion 3 (Reciento 3)
        listaDelegado.add(new Delegado(1,"Universidad Ecotec","Creo","Daniel Mendoza","091290121",34));
        listaDelegado.add(new Delegado(2,"Universidad Ecotec","Pachacutik","Nathaly Landines","091290121",32));
        listaDelegado.add(new Delegado(3,"Universidad Ecotec","Lista35","Pamela Bermeo","091290121",36));
        
        //Recinto 1:
                //Mesa 1
                listaVocal.add(new Vocal("Sagrados Corazones",1,true,"Jose Juan Perez","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",1,false,"Martha Sapienza","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Sagrados Corazones",2,true,"Angel Aguilar","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",2,false,"Polibio Fernandez", "0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Sagrados Corazones",3,true,"Mateo Garbanzo","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",3,false,"Jose Giraldoe","0919551093",50));
                
                //Recinto 2:
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,true,"Felipe Crespo","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",1,false,"Mario Vergara","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,true,"Jurggen Jijon","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",2,false,"Felix Gonzales","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,true,"Carlos Arellanos","0919551093",50));
                listaVocal.add(new Vocal("Universidad Espiritu Santo",3,false,"Brenda Elizalde","0919551093",50));
                
                //Recinto 3:
                listaVocal.add(new Vocal("Universidad Ecotec",1,true,"Harrison Mendoza","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",1,false,"Waleska Campoverderde","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Universidad Ecotec",2,true,"Sandra Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",2,false,"Hellen Diaz","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Universidad Ecotec",3,true,"Nayeli Romero","0919551093",50));
                listaVocal.add(new Vocal("Universidad Ecotec",3,false,"Danilo Eras","0919551093",50));
        
        //Recinto 1:
                listaMesa.add(new Mesa("Sagrados Corazones",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Sagrados Corazones",2,"Mujer",600,592,425,122,45)); //Mesa 2
                listaMesa.add(new Mesa("Sagrados Corazones",2,"Hombre",600,500,300,150,50)); //Mesa 3
                
                //Recinto 2:
                listaMesa.add(new Mesa("Universidad Espiritu Santo",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Universidad Espiritu Santo",2,"Mujer",600,592,425,122,45)); //Mesa 2
                listaMesa.add(new Mesa("Universidad Espiritu Santo",2,"Hombre",600,500,300,150,50)); //Mesa 3
                
                //Recinto 3:
                listaMesa.add(new Mesa("Universidad Ecotec",1,"Hombre",600,580,500,70,10)); //Mesa 1
                listaMesa.add(new Mesa("Universidad Ecotec",2,"Mujer",600,592,425,122,45)); //Mesa 2
                listaMesa.add(new Mesa("Universidad Ecotec",2,"Hombre",600,500,300,150,50)); //Mesa 3      
        
   }
    
    
}
