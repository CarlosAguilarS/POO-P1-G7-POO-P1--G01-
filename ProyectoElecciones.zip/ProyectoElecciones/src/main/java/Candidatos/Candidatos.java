/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Candidatos;

import Persona.SuperClasePersona;

/**
 *
 * @author carlo
 */
public class Candidatos extends SuperClasePersona {

    
    
    protected String Partido;
    
    public Candidatos(String Partido, String nombre, String cedula, int edad) {
        super(nombre, cedula, edad);
        this.Partido = Partido;
    }

    
    
    
    

    

    public String getPartido() {
        return Partido;
    }

    public void setPartido(String Partido) {
        this.Partido = Partido;
    }
    
    
    /*public void NombreCandidatos1(){
       
        
        Candidatos CandidatoX[] = new Candidatos[4];
        CandidatoX[0] = new Candidatos("Creo","Guillermo Lasso","0919551093",50);
        CandidatoX[1] = new Candidatos("PSC","Cinthya Viteri","0919551093",50);
        CandidatoX[2] = new Candidatos("35xd","Rafael Correa","0919551093",50);
        
    }*/

  
public String mostrarDatos(){
        return "\n Partido: "+Partido+ "\n Nombre: "+nombre+ "\n Cedula: "+cedula+ "\n Edad: "+edad;
        
}    
    
}
