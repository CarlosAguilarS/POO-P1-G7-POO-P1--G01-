/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

/**
 *
 * @author carlo
 */
public class ProyectoElecciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Main objMain = new Main();
        
        //Llamado a la función "MenúUsuario" dentro de la clase "Main", que mostrará el Menú de acciones.
        objMain.MenúUsario();
        
    }
    
}
