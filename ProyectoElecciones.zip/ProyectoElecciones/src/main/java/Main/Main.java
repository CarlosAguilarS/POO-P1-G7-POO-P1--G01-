/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
import Candidatos.Candidatos;
import Delegados.Delegado;
import Vocales.Vocal;
import InicializarSIstema.InicializarSistema;
import java.util.Scanner;
import java .util.*;
/**
 *
 * @author carlo
 */
public class Main {
    
    public void MenúUsario(){
        
        InicializarSistema InicializarSistemaxd = new InicializarSistema();
        InicializarSistemaxd.DatosInicializar();
        
        int eleccionUsuario;
       /* String a="";
        String b="";
        String c="";
        int xd=0;
        */
        Scanner entradaDatos = new Scanner(System.in);
        
        System.out.println("¡Bienvenido al Menú!\n");
        System.out.println("A continuación, eliga la opción a realizar:");
        System.out.println("Opción 1 > Mostrar Candidatos");
        System.out.println("Opción 2 > Mostrar Delegados del Partido");//Habra 3 delegados de partido por reciento, uno en cada mesa
        System.out.println("Opción 3 > Mostrar Vocales del Partido");//Habre 2 vocales uno de ellos sera presidente
        System.out.println("Opción 4 > Consultar Lugar Votacion"); //habra 3 lugares de votacion y 3 mesas nomas
        System.out.print("Ingrese su Opción: " );
        eleccionUsuario = entradaDatos.nextInt();
        while(eleccionUsuario < 1 || eleccionUsuario > 4){
            System.out.print("Opción incorrecta. Ingrese una opción perteneciente al Menú: ");
            eleccionUsuario = entradaDatos.nextInt();
        }
        
       //NombreCandidatos objCandidatos = new NombreCandidatos1();
        //Candidatos objCandidato = new Candidatos(a,b,c,xd);
        
        switch(eleccionUsuario){
            case 1:{
                
                /*Candidatos NombresCandidatos[] = new Candidatos[3];
                NombresCandidatos[0] = new Candidatos("Creo","Guillermo Lasso","0919551093",50);
                NombresCandidatos[1] = new Candidatos("PSC","Cinthya Viteri","0919551093",50);
                NombresCandidatos[2] = new Candidatos("35xd","Rafael Correa","0919551093",50);
                */
                
                List<Candidatos>listaCandidatos = new ArrayList<>(); //thankius pa 
                    listaCandidatos.add(new Candidatos("Creo","Guillermo Lasso","0919551093",50));
                    listaCandidatos.add(new Candidatos("PSC","Cinthya Viteri","0919551093",50));
                    listaCandidatos.add(new Candidatos("35xd","Rafael Correa","0919551093",50));
                
                for (Candidatos candidatos: listaCandidatos){
               
                    System.out.println(candidatos.mostrarDatos());
                    System.out.println(""); 
                        
                        
                }
                
                
       

                //objCandidato.NombreCandidatos1();
                //objCandidatos.NombreCandidatos();
                break;
                
            }
            
            case 2:{
                /*//Habre 3 lugadres de votacion y 3 mesas
                Delegado NombresDelegado[] = new Delegado[9];
                //lugar de votacion 1 (Reciento 1)
                NombresDelegado[0] = new Delegado(1,"Unirsidad Espiritu Santo","Creo","Jose Maria","091290121",34);
                NombresDelegado[1] = new Delegado(2,"Unirsidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32);
                NombresDelegado[2] = new Delegado(3,"Unirsidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36);
                
                //lugar de votacion 2 (Reciento 2)
                NombresDelegado[3] = new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34);
                NombresDelegado[4] = new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32);
                NombresDelegado[5] = new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36);
                
                //lugar de votacion 3 (Reciento 3)
                NombresDelegado[6] = new Delegado(1,"Unirsidad Ecotec","Creo","Daniel Mendoza","091290121",34);
                NombresDelegado[7] = new Delegado(2,"Unirsidad Ecotec","Pachacutik","Nathaly Landines","091290121",32);
                NombresDelegado[8] = new Delegado(3,"Unirsidad Ecotec","Lista35","Pamela Bermeo","091290121",36);
                
                for (Delegado personas: NombresDelegado){
                System.out.println(personas.mostrarDatos());
                System.out.println("");
                }*/
                
                List<Delegado>listaDelegado = new ArrayList<>();
                        //lugar de votacion 1 (Reciento 1)
                        listaDelegado.add(new Delegado(1,"Unirsidad Espiritu Santo","Creo","Jose Maria","091290121",34));
                        listaDelegado.add(new Delegado(2,"Unirsidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32));
                        listaDelegado.add(new Delegado(3,"Unirsidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36));
                         //lugar de votacion 2 (Reciento 2)
                        listaDelegado.add(new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34));
                        listaDelegado.add(new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32));
                        listaDelegado.add(new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36));
                        //lugar de votacion 3 (Reciento 3)
                        listaDelegado.add(new Delegado(1,"Unirsidad Ecotec","Creo","Daniel Mendoza","091290121",34));
                        listaDelegado.add(new Delegado(2,"Unirsidad Ecotec","Pachacutik","Nathaly Landines","091290121",32));
                        listaDelegado.add(new Delegado(3,"Unirsidad Ecotec","Lista35","Pamela Bermeo","091290121",36));
                
                for (Delegado delegados: listaDelegado){
               
                    System.out.println(delegados.mostrarDatos());
                    System.out.println(""); 
                        
                        
                }

                //objCandidato.NombreCandidatos1();
                //objCandidatos.NombreCandidatos();
                break;
                
                
            }
            
            
            case 3:{
                
                /*Vocal NombresVocales[] = new Vocal[18];
                
                System.out.println("Reciento 1: ");
                //Mesa 1, reciento 1
                NombresVocales[0] = new Vocal("Sagrados Corazones",1,true,"Jose Juan Perez","0919551093",50);
                NombresVocales[1] = new Vocal("Sagrados Corazones",1,false,"Martha Sapienza","0919551093",50);
                
                
                //Mesa 2, reciento 1
                NombresVocales[2] = new Vocal("Sagrados Corazones",2,true,"Angel Aguilar","0919551093",50);
                NombresVocales[3] = new Vocal("Sagrados Corazones",2,false,"Polibio Fernandez", "0919551093",50);
                
                //Mesa 3, reciento 1
                NombresVocales[4] = new Vocal("Sagrados Corazones",3,true,"Mateo Garbanzo","0919551093",50);
                NombresVocales[5] = new Vocal("Sagrados Corazones",3,false,"Jose Giraldoe","0919551093",50);
                
                System.out.println("---------------------");
                System.out.println("Reciento 2: ");
                 //Mesa 1, reciento 2
                NombresVocales[6] = new Vocal("Unirsidad Espiritu Santo",1,true,"Felipe Crespo","0919551093",50);
                NombresVocales[7] = new Vocal("Unirsidad Espiritu Santo",1,false,"Mario Vergara","0919551093",50);
                
                
                //Mesa 2, reciento 2
                NombresVocales[8] = new Vocal("Unirsidad Espiritu Santo",2,true,"Jurggen Jijon","0919551093",50);
                NombresVocales[9] = new Vocal("Unirsidad Espiritu Santo",2,false,"Felix Gonzales","0919551093",50);
                
                //Mesa 3, reciento 2
                NombresVocales[10] = new Vocal("Unirsidad Espiritu Santo",3,true,"Carlos Arellanos","0919551093",50);
                NombresVocales[11] = new Vocal("Unirsidad Espiritu Santo",3,false,"Brenda Elizalde","0919551093",50);
                
                System.out.println("---------------------");
                System.out.println("Reciento 3: ");
                  //Mesa 1, reciento 3
                NombresVocales[12] = new Vocal("Unirsidad Ecotec",1,true,"Harrison Mendoza","0919551093",50);
                NombresVocales[13] = new Vocal("Unirsidad Ecotec",1,false,"Waleska Campoverderde","0919551093",50);
                
                
                //Mesa 2, reciento 3
                NombresVocales[14] = new Vocal("Unirsidad Ecotec",2,true,"Sandi Romero","0919551093",50);
                NombresVocales[15] = new Vocal("Unirsidad Ecotec",2,false,"Hellen Diaz","0919551093",50);
                
                //Mesa 3, reciento 3
                NombresVocales[16] = new Vocal("Unirsidad Ecotec",3,true,"Nayeli Romero","0919551093",50);
                NombresVocales[17] = new Vocal("Unirsidad Ecotec",3,false,"Danilo Eras","0919551093",50);
                
                
                
                for (Vocal personas: NombresVocales){
                System.out.println(personas.mostrarDatos());
                
                System.out.println("");
                }*/

                
                List<Vocal>listaVocal = new ArrayList<>();
                
                //Recinto 1:
                //Mesa 1
                listaVocal.add(new Vocal("Sagrados Corazones",1,true,"Jose Juan Perez","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",1,false,"Martha Sapienza","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Sagrados Corazones",2,true,"Angel Aguilar","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",2,false,"Polibio Fernandez", "0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Sagrados Corazones",3,true,"Mateo Garbanzo","0919551093",50));
                listaVocal.add(new Vocal("Sagrados Corazones",3,false,"Jose Giraldoe","0919551093",50));
                
                //Recinto 2:
                listaVocal.add(new Vocal("Unirsidad Espiritu Santo",1,true,"Felipe Crespo","0919551093",50));
                listaVocal.add(new Vocal("Unirsidad Espiritu Santo",1,false,"Mario Vergara","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Unirsidad Espiritu Santo",2,true,"Jurggen Jijon","0919551093",50));
                listaVocal.add(new Vocal("Unirsidad Espiritu Santo",2,false,"Felix Gonzales","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Unirsidad Espiritu Santo",3,true,"Carlos Arellanos","0919551093",50));
                listaVocal.add(new Vocal("Unirsidad Espiritu Santo",3,false,"Brenda Elizalde","0919551093",50));
                
                //Recinto 3:
                listaVocal.add(new Vocal("Unirsidad Ecotec",1,true,"Harrison Mendoza","0919551093",50));
                listaVocal.add(new Vocal("Unirsidad Ecotec",1,false,"Waleska Campoverderde","0919551093",50));
                //Mesa 2
                listaVocal.add(new Vocal("Unirsidad Ecotec",2,true,"Sandra Romero","0919551093",50));
                listaVocal.add(new Vocal("Unirsidad Ecotec",2,false,"Hellen Diaz","0919551093",50));
                //Mesa 3
                listaVocal.add(new Vocal("Unirsidad Ecotec",3,true,"Nayeli Romero","0919551093",50));
                listaVocal.add(new Vocal("Unirsidad Ecotec",3,false,"Danilo Eras","0919551093",50));
                
                for (Vocal vocales: listaVocal){
               
                    System.out.println(vocales.mostrarDatos());
                    System.out.println(""); 
                        
                        
                }
                //objCandidato.NombreCandidatos1();
                //objCandidatos.NombreCandidatos();
                break;
                
            }
        
        
            case 4:{
                
                 List<Delegado>listaDelegado = new ArrayList<>();
                        //lugar de votacion 1 (Reciento 1)
                        listaDelegado.add(new Delegado(1,"Unirsidad Espiritu Santo","Creo","Jose Maria","091290121",34));
                        listaDelegado.add(new Delegado(2,"Unirsidad Espiritu Santo","Pachacutik","Vicente Perez","091290121",32));
                        listaDelegado.add(new Delegado(3,"Unirsidad Espiritu Santo","Lista35","Mario Maximiliano","091290121",36));
                         //lugar de votacion 2 (Reciento 2)
                        listaDelegado.add(new Delegado(1,"Sagrados Corazones","Creo","Pedro Rocafuerte","091290121",34));
                        listaDelegado.add(new Delegado(2,"Sagrados Corazones","Pachacutik","Dayeli Brenda","091290121",32));
                        listaDelegado.add(new Delegado(3,"Sagrados Corazones","Lista35","Luigi Lozano","091290121",36));
                        //lugar de votacion 3 (Reciento 3)
                        listaDelegado.add(new Delegado(1,"Unirsidad Ecotec","Creo","Daniel Mendoza","091290121",34));
                        listaDelegado.add(new Delegado(2,"Unirsidad Ecotec","Pachacutik","Nathaly Landines","091290121",32));
                        listaDelegado.add(new Delegado(3,"Unirsidad Ecotec","Lista35","Pamela Bermeo","091290121",36));
                
                int opc;
                System.out.println("Escoja el lugar de votacion que desea consultar");
                System.out.println("Reciento 1: Universidad Espiritu Santo ");
                System.out.println("Reciento 2: Sagrados Corazones ");
                System.out.println("Reciento 3: Universidad Ecotec");
                 opc = entradaDatos.nextInt();
                while(opc < 1 || opc > 3){
                System.out.print("Opción incorrecta. Ingrese una opción perteneciente al Menú: ");
                opc = entradaDatos.nextInt();
                }
                
                switch(opc){
                    
                    case 2: 
                       String a = new String ("Sagrados Corazones");
                        
                        InicializarSistemaxd.DatosInicializar();
                        
                        System.out.println("\n** Sagrado Corazones**");
                        for (Delegado delegados: listaDelegado){
               
                        if (delegados.getLugarVotacion().equalsIgnoreCase(a)){
                           System.out.println(delegados.mostrarDatos());
                            System.out.println(""); 
                        }
                        
                        }
                    break;
                    }
                    
                 
                
               
                break; 
                }
       
               
       

                
            }
            
            
        }
    }
    

