/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vocales;

import Persona.SuperClasePersona;

/**
 *
 * @author carlo
 */
public class Vocal extends SuperClasePersona {
    
    protected String lugarVotacion;
    protected int MesaAsignada;
    protected boolean presidentedeMesa;

    public Vocal(String lugarVotacion, int MesaAsignada, boolean presidentedeMesa, String nombre, String cedula, int edad) {
        super(nombre, cedula, edad);
        this.lugarVotacion = lugarVotacion;
        this.MesaAsignada = MesaAsignada;
        this.presidentedeMesa = presidentedeMesa;
    }

   
    

    public String getLugarVotacion() {
        return lugarVotacion;
    }

    public void setLugarVotacion(String lugarVotacion) {
        this.lugarVotacion = lugarVotacion;
    }

    public int getMesaAsignada() {
        return MesaAsignada;
    }

    public void setMesaAsignada(int MesaAsignada) {
        this.MesaAsignada = MesaAsignada;
    }

    public boolean getPresidentedeMesa() {
        return presidentedeMesa;
    }

    public void setPresidentedeMesa(boolean presidentedeMesa) {
        this.presidentedeMesa = presidentedeMesa;
    }

    
public String mostrarDatos(){
        return "\n Lugar de Votacion: "+lugarVotacion+ "\n Mesa Asignada: "+MesaAsignada+ "\n Presidente: "+presidentedeMesa+  "\n Nombre: "+nombre+ "\n Cedula: "+cedula+ "\n Edad: "+edad;
        
}     
    
    
}
