/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Delegados;

import Persona.SuperClasePersona;

/**
 *
 * @author carlo
 */
public class Delegado extends SuperClasePersona {
    
      protected int MesaAsignada;
      protected String lugarVotacion;
      protected String Partido;

    public Delegado(int MesaAsignada, String lugarVotacion,String Partido, String nombre, String cedula, int edad) {
        super(nombre, cedula, edad);
        this.Partido=Partido;
        this.MesaAsignada = MesaAsignada;
        this.lugarVotacion = lugarVotacion;
    }

    

    public int getMesaAsignada() {
        return MesaAsignada;
    }

    public void setMesaAsignada(int MesaAsignada) {
        this.MesaAsignada = MesaAsignada;
    }

    public String getLugarVotacion() {
        return lugarVotacion;
    }

    public void setLugarVotacion(String lugarVotacion) {
        this.lugarVotacion = lugarVotacion;
    }

    public String getPartido() {
        return Partido;
    }

    public void setPartido(String Partido) {
        this.Partido = Partido;
    }
    
    
    
    /*public void NombreDelegados(){
       
        
        Delegado Delegadoxmesa[] = new Delegado[4];
        Delegadoxmesa[0] = new Delegado(1,"Barrio Centenario","Jose Perez","0919551093",19);
        Delegadoxmesa[1] = new Delegado(2,"Barrio 6 de Marzo","Jose Perez","0919551093",23);
        Delegadoxmesa[2] = new Delegado(3,"Sauces 9","Peptio Sornoza","0919551093",34);
        
        
    }*/
    
    
    public String mostrarDatos(){
        return "\n Lugar de Votacion: "+lugarVotacion+ "\n Mesa Asignada: "+MesaAsignada+ "\n Partido: "+Partido+ "\n Nombre: "+nombre+ "\n Cedula: "+cedula+ "\n Edad: "+edad;
        
} 
    
    
    
    
}
