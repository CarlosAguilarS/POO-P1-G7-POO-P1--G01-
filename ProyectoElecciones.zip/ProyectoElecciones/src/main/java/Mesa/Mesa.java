/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mesa;

import Vocales.Vocal;

/**
 *
 * @author carlo
 */
public class Mesa  {
    
    protected int numeroMesa;
    protected String ubicacionMesa;
    protected String sexoMesa;
    protected int numeroVotantes;
    //protected int numeroVocales;
    //protected int numeroPresidente;
    protected int votosTotales;
    protected int votosPartido1;
    protected int votosPartido2;
    protected int votosPartido3;

    public int getNumeroMesa() {
        return numeroMesa;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public String getUbicacionMesa() {
        return ubicacionMesa;
    }

    public void setUbicacionMesa(String ubicacionMesa) {
        this.ubicacionMesa = ubicacionMesa;
    }

    public String getSexoMesa() {
        return sexoMesa;
    }

    public void setSexoMesa(String sexoMesa) {
        this.sexoMesa = sexoMesa;
    }

    public int getNumeroVotantes() {
        return numeroVotantes;
    }

    public void setNumeroVotantes(int numeroVotantes) {
        this.numeroVotantes = numeroVotantes;
    }

    public int getVotosTotales() {
        return votosTotales;
    }

    public void setVotosTotales(int votosTotales) {
        this.votosTotales = votosTotales;
    }

    public int getVotosPartido1() {
        return votosPartido1;
    }

    public void setVotosPartido1(int votosPartido1) {
        this.votosPartido1 = votosPartido1;
    }

    public int getVotosPartido2() {
        return votosPartido2;
    }

    public void setVotosPartido2(int votosPartido2) {
        this.votosPartido2 = votosPartido2;
    }

    public int getVotosPartido3() {
        return votosPartido3;
    }

    public void setVotosPartido3(int votosPartido3) {
        this.votosPartido3 = votosPartido3;
    }

    
    
}
