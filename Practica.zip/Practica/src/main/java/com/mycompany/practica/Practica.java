/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.practica;
import java.util.Scanner;
/**
 *
 * @author carlo
 */
public class Practica {

    public static void main(String[] args) {
        
        
        
        
        Scanner in = new Scanner(System.in);
        int cedulaTitular=0,opc=0,opc0=0;
        String nombreTitular="";
        float cantidadTitular=0, total=0,cantidad=0;
        Clase1 C1 = new Clase1(cedulaTitular,nombreTitular,cantidadTitular);
        Clase1 C2 = new Clase1(cedulaTitular,nombreTitular);
        
        System.out.println("Ingrese el nombre del titular:"); 
        nombreTitular=in.nextLine();
        System.out.println("Ingrese la cedula del titular:"); 
        cedulaTitular=in.nextInt();
        
        
        System.out.println("Desea ingresar cantidad:    1=Si   2=No"); 
        opc0=in.nextInt();
        
        if(opc0 == 1){
            System.out.println("Ingrese la cantidad que tiene en la cuenta:"); 
            cantidadTitular=in.nextFloat();
        
            C1.setNombre(nombreTitular);
            C1.setCedula(cedulaTitular);
            C1.setCantidad(cantidadTitular);
            
            
            System.out.println("Si desea ingresar una cantidad digite 1"); 
            System.out.println("Si desea retirar una cantidad digite 2"); 
            System.out.println("Si no desea ni retirar ni depositar una cantidad digite 3");
            opc=in.nextInt();

            if(opc==1){

                System.out.println("Digite la cantidad que desea ingresr"); 
                total=in.nextInt();
                
                if(total>0){
                    cantidad=C1.Ingresar(total);
                    C1.setCantidad(cantidad); 
                }
                
                }else if(opc==2){

                System.out.println("Digite la cantidad que desea retirar"); 
                total=in.nextInt();
                cantidad=C1.Retirar(total);
                if(cantidad<0){
                 cantidad=0;   
                }
                C1.setCantidad(cantidad);    

            }

            System.out.println("Nombre: "+C1.getNombre()+" Cedula: "+C1.getCedula()+" cantidad: "+C1.getCantidad());
            
        }else{
            
            C2.setNombre(nombreTitular);
            C2.setCedula(cedulaTitular);
            C2.setCantidad(cantidadTitular);
            System.out.println("Si desea ingresar una cantidad digite 1"); 
            System.out.println("Si desea retirar una cantidad digite 2"); 
            System.out.println("Si no desea ni retirar ni depositar una cantidad digite 3");
            opc=in.nextInt();

            if(opc==1){

                System.out.println("Digite la cantidad que desea ingresr"); 
                total=in.nextInt();
                cantidad=C2.Ingresar(total);
                C2.setCantidad(cantidad);
                }else if(opc==2){

                System.out.println("Digite la cantidad que desea retirar"); 
               total=in.nextInt();
                cantidad=C2.Retirar(total);
                
                if(cantidad<0){
                 cantidad=0;   
                }
                C2.setCantidad(cantidad);    


            }
            
                System.out.println("Nombre: "+C2.getNombre()+" Cedula: "+C2.getCedula()+" cantidad: "+C2.getCantidad());
            
        }
        
       
        
        
        
        
        
        
        
        
        
    
        
        
        
        
        
    }
}
