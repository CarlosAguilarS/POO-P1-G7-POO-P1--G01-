/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica;

/**
 *
 * @author carlo
 */
public class Clase1 {
    
    
    int cedula;
    String nombre;
    public float cantidad;
    
    public Clase1(int c, String n){
        
        cedula = c;
        nombre = n;
        
    }
    
    public Clase1(int c, String n, float can){
        
        cedula = c;
        nombre = n;
        cantidad = can;
    }
    
    public float getCantidad(){
        
      return cantidad;  
    }
    
    public void setCantidad(float cantidad){
        
        this.cantidad = cantidad;
        
    }
    
    public String getNombre(){
        
      return nombre;  
    }
    
    public void setNombre(String nombre){
        
        this.nombre = nombre;
        
    }
    
    public void setCedula(int cedula){
        
        this.cedula = cedula;
        
    }
    
    public int getCedula(){
        
      return cedula;  
    }
    
    public float Retirar(float cantidad2){
        
        
        float total = cantidad-cantidad2;
        return total;
    }
    
    public float Ingresar(float cantidad2){
        
        float total = cantidad+cantidad2;
        return total;
        
    }
    
    
    
}
